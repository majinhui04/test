<?php

return array(

    //图片上传允许的存储目录
    'imageSavePath' => array (
        'upload1', 'upload2', 'upload3'
    )

);